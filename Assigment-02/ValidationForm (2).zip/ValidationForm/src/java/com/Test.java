/*
    Document   : Test.java
    Created on : Feb 16, 2018, 6:47:38 PM
    Author     : priya
    Description: This servlet looks up the longitude and latitude for the entered address using Google API
*/

package com;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URL;
import java.io.InputStream;
import javax.servlet.http.*;

/**
 *
 * @author priya
 */
@WebServlet(urlPatterns = {"/Test"})
public class Test extends HttpServlet {
private static final String GEO_CODE_SERVER = "http://maps.googleapis.com/maps/api/geocode/json?";
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            String street = request.getParameter("streetadd");
            String city = request.getParameter("cityname");
            String state = request.getParameter("statename");
            String location = street+","+city+","+state;
            String customerName = request.getParameter("customername");
            String ssn = request.getParameter("socsecnumb");
            String zip = request.getParameter("zipcode");
            String emailId = request.getParameter("emailadd");
            String response2 = getLocation(location);
            String[] result = parseLocation(response2);
 
            HttpSession session1 = request.getSession(true);
            session1.setAttribute("CName", customerName);
            session1.setAttribute("ssn", ssn);
            session1.setAttribute("zipCode", zip);
            session1.setAttribute("emailAdd", emailId);
            session1.setAttribute("streetAddress", street);
            session1.setAttribute("cityName", city);
            session1.setAttribute("stateName", state);
            session1.setAttribute("Latitude", result[0]);
            session1.setAttribute("Longitude", result[1]);
            request.getRequestDispatcher("ProcessCustomerDataRequest.jsp").include(request, response);
        }
        
    }
    
     private static String getLocation(String code)
    {
        String address = buildUrl(code);

        String content = null;

        try
        {
            URL url = new URL(address);

            InputStream stream = url.openStream();

            try
            {
                int available = stream.available();

                byte[] bytes = new byte[available];

                stream.read(bytes);

                content = new String(bytes);
            }
            finally
            {
                stream.close();
            }

            return (String) content.toString();
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    private static String buildUrl(String code)
    {
        StringBuilder builder = new StringBuilder();

        builder.append(GEO_CODE_SERVER);

        builder.append("address=");
        builder.append(code.replaceAll(" ", "+"));
        builder.append("&sensor=false");

        return builder.toString();
    }

    private static String[] parseLocation(String response)
    {

        String[] lines = response.split("\n");

        String lat = null;
        String lng = null;

        for (int i = 0; i < lines.length; i++)
        {
            if ("\"location\" : {".equals(lines[i].trim()))
            {
                lat = getOrdinate(lines[i+1]);
                lng = getOrdinate(lines[i+2]);
                break;
            }
        }

        return new String[] {lat, lng};
    }

    private static String getOrdinate(String s)
    {
        String[] split = s.trim().split(" ");

        if (split.length < 1)
        {
            return null;
        }

        String ord = split[split.length - 1];

        if (ord.endsWith(","))
        {
            ord = ord.substring(0, ord.length() - 1);
        }

        // Check that the result is a valid double
        Double.parseDouble(ord);

        return ord;
    }

}
